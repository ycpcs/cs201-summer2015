package edu.ycp.cs201.gorilla;


public class AngryGorillasController {
	public void initModel(AngryGorillasModel model) {
		// TODO: initialize the model by adding building Rectangles, gorilla Rectangles, etc.
	}
}
