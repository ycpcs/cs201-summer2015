package edu.ycp.cs201.webcrawler;

import java.util.Scanner;

public class WebCrawler {
	public static void main(String[] args) {
		Scanner keyboard = new Scanner(System.in);
		
		System.out.print("Enter directory: ");
		String directory = keyboard.nextLine();
		
		System.out.print("Enter starting web page URI: ");
		String startingWebPageURI = keyboard.nextLine();
		if (URI.isRelative(startingWebPageURI)) {
			throw new IllegalArgumentException("Starting web page uri must be absolute");
		}
		
		// TODO: crawl all web pages reachable from starting web page
		
		// TODO: print names of visited web pages
		
		// TODO: print all broken links
	}
}
