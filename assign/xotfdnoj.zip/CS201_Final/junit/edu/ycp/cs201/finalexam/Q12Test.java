package edu.ycp.cs201.finalexam;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.junit.Before;
import org.junit.Test;

public class Q12Test {
	private List<String> list1;
	private List<Integer> list2;
	
	@Before
	public void setUp() {
		list1 = new ArrayList<String>(
				Arrays.asList("H", "U", "A", "M", "S", "V", "C", "F", "I", "A"));
		list2 = new ArrayList<Integer>(
				Arrays.asList(69, 98, 71, 74, 63, 40, 83, 59, 38, 89, 32, 25, 97, 94, 52));
	}
	
	@Test
	public void testStringList() throws Exception {
		Q12.collate(list1);
		assertEquals("H", list1.get(0));
		assertEquals("A", list1.get(1));
		assertEquals("S", list1.get(2));
		assertEquals("C", list1.get(3));
		assertEquals("I", list1.get(4));
		assertEquals("U", list1.get(5));
		assertEquals("M", list1.get(6));
		assertEquals("V", list1.get(7));
		assertEquals("F", list1.get(8));
		assertEquals("A", list1.get(9));
	}
	
	@Test
	public void testIntList() throws Exception {
		Q12.collate(list2);
		assertEquals((Integer)69, list2.get(0));
		assertEquals((Integer)71, list2.get(1));
		assertEquals((Integer)63, list2.get(2));
		assertEquals((Integer)83, list2.get(3));
		assertEquals((Integer)38, list2.get(4));
		assertEquals((Integer)32, list2.get(5));
		assertEquals((Integer)97, list2.get(6));
		assertEquals((Integer)52, list2.get(7));
		assertEquals((Integer)98, list2.get(8));
		assertEquals((Integer)74, list2.get(9));
		assertEquals((Integer)40, list2.get(10));
		assertEquals((Integer)59, list2.get(11));
		assertEquals((Integer)89, list2.get(12));
		assertEquals((Integer)25, list2.get(13));
		assertEquals((Integer)94, list2.get(14));
	}
}
