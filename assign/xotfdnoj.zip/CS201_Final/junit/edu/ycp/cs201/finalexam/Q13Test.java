package edu.ycp.cs201.finalexam;

import static org.junit.Assert.*;

import org.junit.Test;

public class Q13Test {
	@Test
	public void testEmpty() throws Exception {
		assertEquals("", Q13.insertCommas(""));
	}
	
	@Test
	public void testSingleChar() throws Exception {
		assertEquals("x", Q13.insertCommas("x"));
	}
	
	@Test
	public void testHello() throws Exception {
		assertEquals("H,e,l,l,o", Q13.insertCommas("Hello"));
	}
	
	@Test
	public void testFinalThought() throws Exception {
		assertEquals("W,e,',r,e, ,d,o,n,e, ,w,i,t,h, ,C,S,2,0,1", Q13.insertCommas("We're done with CS201"));
	}
}
