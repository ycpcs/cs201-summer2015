package edu.ycp.cs201.finalexam;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;

public class Q11 {
	public static<E> E findNthLargest(ArrayList<E> list, int n, Comparator<E> comp) {
		throw new UnsupportedOperationException("TODO - implement");
	}
}
