package edu.ycp.cs201.exam3;

import static org.junit.Assert.*;

import java.util.Arrays;
import java.util.List;

import org.junit.Before;
import org.junit.Test;

public class Q9Test {
	private List<String> list1;
	private List<Integer> list2;
	private List<Character> list3;
	private List<Integer> empty;
	
	@Before
	public void setUp() {
		list1 = Arrays.asList("A", "B", "C", "A");
		list2 = Arrays.asList(1, 3, 5, 11, 14, 1, 16, 12, 0, 11, 7, 16, 15, 11, 4, 2, 16, 10, 18, 6);
		list3 = Arrays.asList(
				'i', 'c', 'i', 'l', 'e', 'n', 'e', 'h', 'd', 'g',
				's', 'a', 'd', 'm', 'i', 'm', 'n', 's', 'n', 'd');
		empty = Arrays.asList();
	}
	
	@Test
	public void testList1() throws Exception {
		assertEquals(3, Q9.countUnique(list1));
	}
	
	@Test
	public void testList2() throws Exception {
		assertEquals(15, Q9.countUnique(list2));
	}
	
	@Test
	public void testList3() throws Exception {
		assertEquals(11, Q9.countUnique(list3));
	}
	
	@Test
	public void testEmpty() throws Exception {
		assertEquals(0, Q9.countUnique(empty));
	}
}
