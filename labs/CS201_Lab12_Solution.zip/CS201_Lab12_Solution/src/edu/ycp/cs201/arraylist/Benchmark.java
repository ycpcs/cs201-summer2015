package edu.ycp.cs201.arraylist;

public class Benchmark {
	public static void main(String[] args) {
		// TODO: benchmark removing all elements from an ArrayList
		// using two techniques
		//
		//   - repeatedly removing the last element
		//   - repeatedly removing the first element
		//
		// Measure the time to remove 10,000, 20,000, etc. elements,
		// up to 100,000 elements, for each technique.
	
		for (int size = 10000; size <= 100000; size += 10000) {
			System.out.print(size);
			
			long begin, end;
			
			// benchmark repeatedly removing last element
			ArrayList<Integer> a1 = create(size);
			System.gc();
			begin = System.currentTimeMillis();
			while (a1.size() > 0) {
				// remove last element
				a1.remove(a1.size()-1);
			}
			end = System.currentTimeMillis();
			System.out.print("," + (end-begin));
			
			// benchmark repeatedly removing first element
			ArrayList<Integer> a2 = create(size);
			System.gc();
			begin = System.currentTimeMillis();
			while (a2.size() > 0) {
				// remove first element
				a2.remove(0);
			}
			end = System.currentTimeMillis();
			System.out.println("," + (end-begin));
		}
	}

	public static ArrayList<Integer> create(int count) {
		ArrayList<Integer> a = new ArrayList<Integer>(count);
		for (int i = 0; i < count; i++) {
			a.add((Integer) 42);
		}
		return a;
	}
}
