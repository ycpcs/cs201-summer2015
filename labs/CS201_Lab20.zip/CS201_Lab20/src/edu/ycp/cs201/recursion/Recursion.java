package edu.ycp.cs201.recursion;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

public class Recursion {
	/**
	 * Use the merge sort algorithm to sort a list.
	 * 
	 * @param list the list to sort
	 */
	public static<E extends Comparable<E>> void mergeSort(List<E> list) {
		mergeSortWork(list, 0, list.size());
	}
	
	/**
	 * Helper method for merge sort: it sorts a specified region
	 * of a List using the merge sort algorithm.
	 * 
	 * @param list   the list
	 * @param start  the start index (inclusive) of the region to sort
	 * @param end    the end index (exclusive) of the region to sort
	 */
	private static<E extends Comparable<E>> void mergeSortWork(List<E> list, int start, int end) {
		throw new UnsupportedOperationException("TODO - implement");
	}
	
	/**
	 * Merge two sorted regions of a list, returning a new list
	 * as a result.
	 * 
	 * @param list    the list
	 * @param start   the start index (inclusive) of the first region
	 * @param mid     the end index (exclusive) of the first region
	 *                and the start index (inclusive) of the second region
	 * @param end     the end index (exclusive) of the second region
	 * @return a sorted List containing all of the elements from each region 
	 */
	public static<E extends Comparable<E>> List<E> merge(List<E> list, int start, int mid, int end) {
		List<E> result = new ArrayList<E>();
		
		int i = start, j = mid;
		while (i < mid || j < end) {
			if (i >= mid) {
				result.add(list.get(j));
				j++;
			} else if (j >= end) {
				result.add(list.get(i));
				i++;
			} else {
				E left = list.get(i);
				E right = list.get(j);
				if (left.compareTo(right) < 0) {
					result.add(left);
					i++;
				} else {
					result.add(right);
					j++;
				}
			}
		}
		
		return result;
	}
	
	/**
	 * Return a Set containing all permutations of the given list.
	 * 
	 * @param list  the list
	 * @return      Set containing all permutations of the list
	 */
	public static<E> Set<List<E>> permute(List<E> list) {
		throw new UnsupportedOperationException("TODO - implement");
	}
}
