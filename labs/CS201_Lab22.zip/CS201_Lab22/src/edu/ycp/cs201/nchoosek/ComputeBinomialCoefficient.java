package edu.ycp.cs201.nchoosek;

public interface ComputeBinomialCoefficient {
	public int compute(int n, int k);
}
