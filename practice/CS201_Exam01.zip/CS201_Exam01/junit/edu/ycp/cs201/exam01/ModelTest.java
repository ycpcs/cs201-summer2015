package edu.ycp.cs201.exam01;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

/**
 * Basic JUnit tests for the {@link Model class}.
 * Checks that an instance of the Model class has
 * at least one {@link Ball} object.  Also tests the
 * {@link Model#setWidth(double)} and
 * {@link Model#setHeight(double)} methods.
 */
public class ModelTest {
	private static final double DELTA = 0.000001;
	
	private Model model;
	private Model model2;
	
	@Before
	public void setUp() {
		model = new Model();
		model2 = new Model();
	}
	
	@Test
	public void testGetNumBalls() throws Exception {
		assertTrue(model.getNumBalls() >= 1);
	}
	
	@Test
	public void testGetBall() throws Exception {
		Ball b = model.getBall(0);
		assertNotNull(b);
	}
	
	@Test
	public void testBallFieldsSetToZero() throws Exception {
		// When a Model object is constructed, all of the fields
		// of its Ball object(s) should be set to 0
		Ball b = model.getBall(0);
		assertEquals(0.0, b.getX(), DELTA);
		assertEquals(0.0, b.getY(), DELTA);
		assertEquals(0.0, b.getDx(), DELTA);
		assertEquals(0.0, b.getDy(), DELTA);
	}
	
	@Test
	public void testSetWidth() throws Exception {
		model.setWidth(400.0);
		model2.setWidth(480.51);
		assertEquals(400.0, model.getWidth(), DELTA);
		assertEquals(480.51, model2.getWidth(), DELTA);
	}
	
	@Test
	public void testSetHeight() throws Exception {
		model.setHeight(500.17);
		model2.setHeight(360.0);
		assertEquals(500.17, model.getHeight(), DELTA);
		assertEquals(360.0, model2.getHeight(), DELTA);
	}
}
