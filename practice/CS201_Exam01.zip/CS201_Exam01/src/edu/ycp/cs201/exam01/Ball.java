package edu.ycp.cs201.exam01;

/**
 * A Ball is a circle with a center point which is
 * moving in a direction and velocity specified by dx and dy values.
 * The Ball's dx value specifies how much x changes per
 * time step, and the Ball's dy value specifies how
 * much y changes per time step.
 */
public class Ball {
	// TODO: add fields
	
	/**
	 * Constructor.
	 * 
	 * @param x  the Ball's initial x coordinate
	 * @param y  the Ball's initial y coordinate
	 * @param dx the Ball's initial dx value 
	 * @param dy the Ball's initial dy value
	 */
	public Ball(double x, double y, double dx, double dy) {
		throw new UnsupportedOperationException("TODO - implement");
	}
	
	/**
	 * @return the Ball's x coordinate value
	 */
	public double getX() {
		throw new UnsupportedOperationException("TODO - implement");
	}
	
	/**
	 * Set the Ball's x coordinate value.
	 * 
	 * @param x the x coordinate value to set
	 */
	public void setX(double x) {
		throw new UnsupportedOperationException("TODO - implement");
	}
	
	/**
	 * @return the Ball's y coordinate value
	 */
	public double getY() {
		throw new UnsupportedOperationException("TODO - implement");
	}
	
	/**
	 * Set the Ball's y coordinate value.
	 * 
	 * @param y the y coordinate value to set
	 */
	public void setY(double y) {
		throw new UnsupportedOperationException("TODO - implement");
	}
	
	/**
	 * @return the Ball's dx value
	 */
	public double getDx() {
		throw new UnsupportedOperationException("TODO - implement");
	}
	
	/**
	 * Set the Ball's dx value.
	 * 
	 * @param dx the dx value to set
	 */
	public void setDx(double dx) {
		throw new UnsupportedOperationException("TODO - implement");
	}
	
	/**
	 * @return the Ball's dy value
	 */
	public double getDy() {
		throw new UnsupportedOperationException("TODO - implement");
	}

	/**
	 * Set the Ball's dy value.
	 * 
	 * @param dy the dy value to set
	 */
	public void setDy(double dy) {
		throw new UnsupportedOperationException("TODO - implement");
	}
}
