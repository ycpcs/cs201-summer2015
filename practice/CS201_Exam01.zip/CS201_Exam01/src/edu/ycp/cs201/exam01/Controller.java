package edu.ycp.cs201.exam01;

import java.util.Random;

public class Controller {
	public void initBalls(Model model) {
		Random rng = new Random();
		for (int i = 0; i < model.getNumBalls(); i++) {
			Ball b = model.getBall(i);
			b.setX(rng.nextDouble() * model.getWidth());
			b.setY(rng.nextDouble() * model.getHeight());
			b.setDx(10.0 * (rng.nextDouble() * 2 - 1));
			b.setDy(10.0 * (rng.nextDouble() * 2 - 1));
		}
	}

	public void timerTick(Model model) {
		for (int i = 0; i < model.getNumBalls(); i++) {
			Ball b = model.getBall(i);
			
			double nextX = b.getX() + b.getDx();
			double nextY = b.getY() + b.getDy();
			
			if (nextX < 0 || nextX > model.getWidth()) {
				b.setDx(b.getDx() * -1);
			}
			
			if (nextY < 0 || nextY > model.getHeight()) {
				b.setDy(b.getDy() * -1);
			}
			
			b.setX(b.getX() + b.getDx());
			b.setY(b.getY() + b.getDy());
		}
	}
}
