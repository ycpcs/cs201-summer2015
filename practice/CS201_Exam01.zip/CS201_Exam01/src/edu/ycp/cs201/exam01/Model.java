package edu.ycp.cs201.exam01;

import java.util.ArrayList;

/**
 * A Model object represents a collection of {@link Ball}
 * objects, which are located on a playing field of
 * a width and height (also stored in the model).
 * A minimal version of the Model class should support
 * at least one {@link Ball} object.  A more complete
 * implementation should support at least 10 {@link Ball}
 * objects.
 */
public class Model {
	// TODO: add fields
	
	/**
	 * Constructor.
	 * Should create and store a collection of (one or more)
	 * {@link Ball} objects.  The initial width and height
	 * of the playing field should be set to 0.
	 * <em>Note</em> The {@link Ball} objects that are
	 * created by the constructor should have their x, y, dx, and dy
	 * values all set to 0.
	 */
	public Model() {
		throw new UnsupportedOperationException("TODO - implement");
	}
	
	/**
	 * @return the number of {@link Ball} objects
	 */
	public int getNumBalls() {
		throw new UnsupportedOperationException("TODO - implement");
	}

	/**
	 * Get the {@link Ball} object whose index is given (0 for the first
	 * one, 1 for the second one, etc.)
	 * 
	 * @param index the index
	 * @return the {@link Ball} object at that index
	 */
	public Ball getBall(int index) {
		throw new UnsupportedOperationException("TODO - implement");
	}
	
	/**
	 * @return the width of the playing field
	 */
	public double getWidth() {
		throw new UnsupportedOperationException("TODO - implement");
	}
	
	/**
	 * Set the width of the playing field.
	 * 
	 * @param width the width to set
	 */
	public void setWidth(double width) {
		throw new UnsupportedOperationException("TODO - implement");
	}
	
	/**
	 * @return the height of the playing field 
	 */
	public double getHeight() {
		throw new UnsupportedOperationException("TODO - implement");
	}
	
	/**
	 * Set the height of the playing field.
	 * 
	 * @param height the height to set
	 */
	public void setHeight(double height) {
		throw new UnsupportedOperationException("TODO - implement");
	}
}
