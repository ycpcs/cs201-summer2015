package edu.ycp.cs201.exam01;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

/**
 * Advanced JUnit tests for the {@link Model class}.
 * Checks that an instance of the Model class has
 * at least 10 {@link Ball} objects, all of which are
 * independent of each other.
 */
public class AdvancedModelTest {
	private static final double DELTA = 0.000001;

	private Model model;
	
	@Before
	public void setUp() {
		model = new Model();
	}
	
	@Test
	public void testGetNumBalls() throws Exception {
		assertTrue(model.getNumBalls() >= 10);
	}
	
	@Test
	public void testGetBall() throws Exception {
		for (int i = 0; i < 10; i++) {
			Ball b = model.getBall(i);
			assertNotNull(b);
		}
	}
	
	@Test
	public void testBallFieldsSetToZero() throws Exception {
		for (int i = 0; i < 10; i++) {
			Ball b = model.getBall(i);
			assertEquals(0.0, b.getX(), DELTA);
			assertEquals(0.0, b.getY(), DELTA);
			assertEquals(0.0, b.getDx(), DELTA);
			assertEquals(0.0, b.getDy(), DELTA);
		}
	}
	
	@Test
	public void testSetBallLocations() {
		// Test that each Ball has an independent location
		for (int i = 0; i < 10; i++) {
			Ball b = model.getBall(i);
			b.setX(12.3 * i);
		}
		for (int i = 0; i < 10; i++) {
			Ball b = model.getBall(i);
			assertEquals(12.3 * i, b.getX(), DELTA);
		}
	}
}
