package edu.ycp.cs201.exam01;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

/**
 * JUnit tests for the {@link Ball} class.
 */
public class BallTest {
	private static final double DELTA = 0.000001;
	
	private Ball c1;
	private Ball c2;
	
	@Before
	public void setUp() {
		c1 = new Ball(3.1, 4.2, 1.5, 2.3);
		c2 = new Ball(-9.1, 11.5, -8.2, -1.1);
	}
	
	@Test
	public void testGetX() throws Exception {
		assertEquals(3.1, c1.getX(), DELTA);
		assertEquals(-9.1, c2.getX(), DELTA);
	}
	
	@Test
	public void testSetX() throws Exception {
		c1.setX(100.11);
		assertEquals(100.11, c1.getX(), DELTA);
	}
	
	@Test
	public void testGetY() throws Exception {
		assertEquals(4.2, c1.getY(), DELTA);
		assertEquals(11.5, c2.getY(), DELTA);
	}
	
	@Test
	public void testSetY() throws Exception {
		c1.setY(291.8);
		assertEquals(291.8, c1.getY(), DELTA);
	}
	
	@Test
	public void testGetDx() throws Exception {
		assertEquals(1.5, c1.getDx(), DELTA);
		assertEquals(-8.2, c2.getDx(), DELTA);
	}
	
	@Test
	public void testSetDx() throws Exception {
		c1.setDx(66.87);
		assertEquals(66.87, c1.getDx(), DELTA);
	}
	
	@Test
	public void testGetDy() throws Exception {
		assertEquals(2.3, c1.getDy(), DELTA);
		assertEquals(-1.1, c2.getDy(), DELTA);
	}
	
	@Test
	public void testSetDy() throws Exception {
		c1.setDy(-81.46);
		assertEquals(-81.46, c1.getDy(), DELTA);
	}
}
