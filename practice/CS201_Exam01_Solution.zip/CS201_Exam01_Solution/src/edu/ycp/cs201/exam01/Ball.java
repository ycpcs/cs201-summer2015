package edu.ycp.cs201.exam01;

/**
 * A Ball is a circle with a center point which is
 * moving in a direction and velocity specified by dx and dy values.
 * The Ball's dx value specifies how much x changes per
 * time step, and the Ball's dy value specifies how
 * much y changes per time step.
 */
public class Ball {
	// TODO: add fields
	private double x, y, dx, dy;
	
	/**
	 * Constructor.
	 * 
	 * @param x  the Ball's initial x coordinate
	 * @param y  the Ball's initial y coordinate
	 * @param dx the Ball's initial dx value 
	 * @param dy the Ball's initial dy value
	 */
	public Ball(double x, double y, double dx, double dy) {
		this.x = x;
		this.y = y;
		this.dx = dx;
		this.dy = dy;
	}
	
	/**
	 * @return the Ball's x coordinate value
	 */
	public double getX() {
		return this.x;
	}
	
	/**
	 * Set the Ball's x coordinate value.
	 * 
	 * @param x the x coordinate value to set
	 */
	public void setX(double x) {
		this.x = x;
	}
	
	/**
	 * @return the Ball's y coordinate value
	 */
	public double getY() {
		return this.y;
	}
	
	/**
	 * Set the Ball's y coordinate value.
	 * 
	 * @param y the y coordinate value to set
	 */
	public void setY(double y) {
		this.y = y;
	}
	
	/**
	 * @return the Ball's dx value
	 */
	public double getDx() {
		return this.dx;
	}
	
	/**
	 * Set the Ball's dx value.
	 * 
	 * @param dx the dx value to set
	 */
	public void setDx(double dx) {
		this.dx = dx;
	}
	
	/**
	 * @return the Ball's dy value
	 */
	public double getDy() {
		return this.dy;
	}

	/**
	 * Set the Ball's dy value.
	 * 
	 * @param dy the dy value to set
	 */
	public void setDy(double dy) {
		this.dy = dy;
	}
}
