package edu.ycp.cs201.exam01;

import java.util.ArrayList;

/**
 * A Model object represents a collection of {@link Ball}
 * objects, which are located on a playing field of
 * a width and height (also stored in the model).
 * A minimal version of the Model class should support
 * at least one {@link Ball} object.  A more complete
 * implementation should support at least 10 {@link Ball}
 * objects.
 */
public class Model {
	// TODO: add fields
	private ArrayList<Ball> balls;
	private double width, height;
	
	/**
	 * Constructor.
	 * Should create and store a collection of (one or more)
	 * {@link Ball} objects.  The initial width and height
	 * of the playing field should be set to 0.
	 * <em>Note</em> The {@link Ball} objects that are
	 * created by the constructor should have their x, y, dx, and dy
	 * values all set to 0.
	 */
	public Model() {
		this.balls = new ArrayList<Ball>();
		for (int i = 0; i < 10; i++) {
			balls.add(new Ball(0, 0, 0, 0));
		}
		this.width = 0;
		this.height = 0;
	}
	
	/**
	 * @return the number of {@link Ball} objects
	 */
	public int getNumBalls() {
		return balls.size();
	}

	/**
	 * Get the {@link Ball} object whose index is given (0 for the first
	 * one, 1 for the second one, etc.)
	 * 
	 * @param index the index
	 * @return the {@link Ball} object at that index
	 */
	public Ball getBall(int index) {
		return balls.get(index);
	}
	
	/**
	 * @return the width of the playing field
	 */
	public double getWidth() {
		return this.width;
	}
	
	/**
	 * Set the width of the playing field.
	 * 
	 * @param width the width to set
	 */
	public void setWidth(double width) {
		this.width = width;
	}
	
	/**
	 * @return the height of the playing field 
	 */
	public double getHeight() {
		return this.height;
	}
	
	/**
	 * Set the height of the playing field.
	 * 
	 * @param height the height to set
	 */
	public void setHeight(double height) {
		this.height = height;
	}
}
