package edu.ycp.cs201.exam01;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Random;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.SwingUtilities;
import javax.swing.Timer;

public class View extends JPanel {
	private static final double BALL_RADIUS = 15.0;
	
	private static final Color DARK_GREEN = new Color(0, 100, 0);

	private Model model;
	private Controller controller;
	
	public View() {
		setBackground(DARK_GREEN);
		Timer timer = new Timer(1000/30, new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				handleTimerTick();
			}
		});
		timer.start();
	}
	
	protected void handleTimerTick() {
		if (model == null) {
			return;
		}
		controller.timerTick(model);
		repaint();
	}
	
	public void setModel(Model model) {
		this.model = model;
		double width = model.getWidth() + BALL_RADIUS*2;
		double height = model.getHeight() + BALL_RADIUS*2;
		setPreferredSize(new Dimension((int)width, (int)height));
	}
	
	public void setController(Controller controller) {
		this.controller = controller;
	}
	
	@Override
	protected void paintComponent(Graphics g) {
		super.paintComponent(g);
		
//		g.setColor(Color.DARK_GRAY);
//		g.fillRect((int)BALL_RADIUS, (int)BALL_RADIUS, (int)model.getWidth(), (int)model.getHeight());
		
		Random rng = new Random(123L);
		for (int i = 0; i < model.getNumBalls(); i++) {
			Ball b = model.getBall(i);
			Color c = new Color(rng.nextInt(1 << 24));
			g.setColor(c);
			double x = b.getX();
			double y = b.getY();
			double wh = BALL_RADIUS*2;
			g.fillOval((int)x, (int)y, (int)wh, (int)wh);
		}
	}
	
	public static void main(String[] args) {
		SwingUtilities.invokeLater(new Runnable() {
			@Override
			public void run() {
				Model model = new Model();
				View view = new View();
				Controller controller = new Controller();
				
				model.setWidth(640.0);
				model.setHeight(480.0);
				
				controller.initBalls(model);
				
				view.setModel(model);
				view.setController(controller);
				
				JFrame frame = new JFrame("CS 201 - Exam 1");
				frame.setContentPane(view);
				frame.pack();
				frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
				
				frame.setVisible(true);
			}
		});
	}
}
