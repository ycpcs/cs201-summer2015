package edu.ycp.cs201.exam2;

import static org.junit.Assert.*;

import org.junit.Test;

public class Q6Test {
	@Test
	public void testReplaceIt1() throws Exception {
		assertEquals("Om NOM NOM NOM", Q6.replaceIt("Om X X X", 'X', "NOM"));
	}
	
	@Test
	public void testReplaceIt2() throws Exception {
		assertEquals("Om NOM Y Z", Q6.replaceIt("Om X Y Z", 'X', "NOM"));
	}
	
	@Test
	public void testReplaceItNoSpaces() throws Exception {
		assertEquals("OmNOMYNOMZNOM", Q6.replaceIt("OmXYXZX", 'X', "NOM"));
	}
	
	@Test
	public void testReplaceItWithAtSign() throws Exception {
		assertEquals("Feed me some turnip, please",
				Q6.replaceIt("Feed me some @, please", '@', "turnip"));
	}
	
	@Test
	public void testReplaceItAtBeginning() throws Exception {
		assertEquals("Bees come down", Q6.replaceIt("#s come down", '#', "Bee"));
	}
	
	@Test
	public void testReplaceItAtEnd() throws Exception {
		assertEquals("Please pass the prawns",
				Q6.replaceIt("Please pass the $", '$', "prawns"));
	}
	
	@Test
	public void testReplaceItNoOccurrences() throws Exception {
		assertEquals("A smell of petroleum prevails throughout",
				Q6.replaceIt("A smell of petroleum prevails throughout", 'X', "NOM"));
	}
}
