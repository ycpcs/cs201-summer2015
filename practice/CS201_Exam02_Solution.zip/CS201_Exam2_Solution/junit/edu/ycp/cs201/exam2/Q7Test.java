package edu.ycp.cs201.exam2;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.Before;
import org.junit.Test;

public class Q7Test {
	private Map<String, Integer> thePrices;
	private List<String> order1;
	private List<String> order2;
	private List<String> allItems;
	private List<String> hasMissingItem;
	
	@Before
	public void setUp() {
		thePrices = new HashMap<String, Integer>();
		thePrices.put("turnip", 5);
		thePrices.put("squash", 2);
		thePrices.put("coconut", 6);
		thePrices.put("yam", 3);
		thePrices.put("carrot", 1);
		thePrices.put("onion", 2);
		thePrices.put("spam", 4);
		thePrices.put("baked beans", 2);
		
		order1 = Arrays.asList("turnip", "carrot", "yam");
		
		order2 = Arrays.asList("spam", "spam", "spam", "spam", "spam", "baked beans", "spam", "spam", "spam");
		
		allItems = new ArrayList<String>();
		allItems.addAll(thePrices.keySet());
		
		hasMissingItem = Arrays.asList("carrot", "onion", "pear");
	}
	
	@Test
	public void testTally() throws Exception {
		assertEquals(9, Q7.tally(thePrices, order1));
	}
	
	@Test
	public void testTallyOrderWithMultipleItems() throws Exception {
		assertEquals(4*8 + 2, Q7.tally(thePrices, order2));
	}
	
	@Test
	public void testTallyOrderAllItems() throws Exception {
		assertEquals(5+2+6+3+1+2+4+2, Q7.tally(thePrices, allItems));
	}
	
	@Test
	public void testTallyMissingItem() throws Exception {
		try {
			Q7.tally(thePrices, hasMissingItem);
			assertTrue("An exception should have been thrown", false);
		} catch (IllegalArgumentException e) {
			// Good
		}
	}
}
