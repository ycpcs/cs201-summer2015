package edu.ycp.cs201.exam2;

public class Q6 {
	/**
	 * Replace all occurences of given character <code>c</code>
	 * in String <code>s</code> with the string <code>r</code>.
	 * Your implementation <em>must</em> be recursive!
	 * 
	 * @param s a String
	 * @param c a character to replace
	 * @param r the string to replace occurrences of <code>c</code> with
	 * @return the transformed string
	 */
	public static String replaceIt(String s, char c, String r) {
		// Base case
		if (s.equals("")) {
			return "";
		}
		
		if (s.charAt(0) == c) {
			return r + replaceIt(s.substring(1), c, r);
		} else {
			return s.charAt(0) + replaceIt(s.substring(1), c, r);
		}
	}
}
