package edu.ycp.cs201.exam2;

import java.util.List;
import java.util.Map;

public class Q7 {
	/**
	 * Return the price of an order.
	 * 
	 * @param prices map of item names to prices in dollars
	 * @param order list of item names
	 * @return the total cost in dollars of the items in the order
	 */
	public static int tally(Map<String, Integer> prices, List<String> order) {
		int sum = 0;
		
		for (String item : order) {
			if (!prices.containsKey(item)) {
				// Prices map doesn't contain this item
				throw new IllegalArgumentException();
			}
			sum += prices.get(item);
		}
		
		return sum;
	}
}
