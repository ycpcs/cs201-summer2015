package edu.ycp.cs201.finalexam;

import static org.junit.Assert.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.Before;
import org.junit.Test;

public class Q11Test {
	// Test objects
	private Map<String, Integer> fruit;
	private Map<String, Integer> votes;
	
	@Before
	public void setUp() {
		fruit = new HashMap<String, Integer>();
		fruit.put("apples", 2);
		fruit.put("oranges", 3);
		
		votes = new HashMap<String, Integer>();
		votes.put("Alice", 579);
		votes.put("Bob", 671);
		votes.put("Cynthia", 979);
	}
	
	@Test
	public void testFruitTwoApples() throws Exception {
		List<String> list = Q11.frequencyMapToList(fruit);
		assertEquals(2, countOccurrences(list, "apples"));
	}
	
	@Test
	public void testFruitThreeOranges() throws Exception {
		List<String> list = Q11.frequencyMapToList(fruit);
		assertEquals(3, countOccurrences(list, "oranges"));
	}
	
	@Test
	public void testFruitNumItems() throws Exception {
		List<String> list = Q11.frequencyMapToList(fruit);
		assertEquals(5, list.size());
	}
	
	@Test
	public void testVotesAlice579() throws Exception {
		List<String> list = Q11.frequencyMapToList(votes);
		assertEquals(579, countOccurrences(list, "Alice"));
	}
	
	@Test
	public void testVotesBob671() throws Exception {
		List<String> list = Q11.frequencyMapToList(votes);
		assertEquals(671, countOccurrences(list, "Bob"));
	}
	
	@Test
	public void testVotesCynthia979() throws Exception {
		List<String> list = Q11.frequencyMapToList(votes);
		assertEquals(979, countOccurrences(list, "Cynthia"));
	}
	
	@Test
	public void testVotesNumItems() throws Exception {
		List<String> list = Q11.frequencyMapToList(votes);
		assertEquals(579+671+979, list.size());
	}
	
	/**
	 * Count the number of occurrences of s in list.
	 * 
	 * @param list a list of strings
	 * @param s a test string
	 * @return the number of times that s occurs in list
	 */
	public static int countOccurrences(List<String> list, String s) {
		int count = 0;
		for (String elt : list) {
			if (elt.equals(s)) {
				count++;
			}
		}
		return count;
	}
}
