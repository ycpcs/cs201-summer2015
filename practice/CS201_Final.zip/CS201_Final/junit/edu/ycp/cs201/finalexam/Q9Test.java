package edu.ycp.cs201.finalexam;

import static org.junit.Assert.*;

import org.junit.Test;

public class Q9Test {
	@Test
	public void testJava() throws Exception {
		assertEquals("'Java' is fun", Q9.beIronic("Java is fun", "Java"));
	}
	
	@Test
	public void testFun() throws Exception {
		assertEquals("Java is 'fun'", Q9.beIronic("Java is fun", "fun"));
	}
	
	@Test
	public void testBacon() throws Exception {
		assertEquals("Java is fun", Q9.beIronic("Java is fun", "bacon"));
	}
	
	@Test
	public void testEmptyString() throws Exception {
		assertEquals("", Q9.beIronic("", "plesiosaur"));
	}
}
