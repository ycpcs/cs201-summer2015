package edu.ycp.cs201.finalexam;

public class Q10 {
	/**
	 * [15 points]
	 * Compute the "digit parity" of the given integer, which you may
	 * assume is non-negative.  The digit parity of an integer n
	 * is defined recursively as follows:
	 * <ul>
	 * <li> If n=0, its digit parity is 0
	 * <li> If n is positive, find the digit parity of the
	 *      integer containing every digit except for the last digit.
	 *      (This can be considered to be 0 if n has only 1 digit.)
	 *      Call this r.  If the last digit is even, then the digit
	 *      parity of n is r.  Otherwise (if the last digit
	 *      of n is odd) the digit parity of the
	 *      n is 0 if r=1, and 1 if r=0.
	 * </ul>
	 * 
	 * <p>Requirement: Your method <em>must</em> be recursive.  Do not use a loop.
	 * Do not use static field(s).
	 * 
	 * <p>Examples:
	 * <ul>
	 * <li> Q10.digitParity(436) should yield 1
	 * <li> Q10.digitParity(792) should yield 0
	 * <li> Q10.digitParity(787) should yield 0
	 * <li> Q10.digitParity(482) should yield 0
	 * <li> Q10.digitParity(555) should yield 1
	 * <li> Q10.digitParity(90125) should yield 1
	 * <li> Q10.digitParity(0) should yield 0
	 * </ul>
	 * 
	 * <p>Hints:
	 * <ul>
	 * <li> Use n%10 to get the last digit
	 * <li> Use n/10 to get the integer with all digits except for the
	 *      last digit
	 * <li> The case where n=0 would probably make a good base case
	 * </ul>
	 * 
	 * @param n
	 * @return the digit parity of n
	 */
	public static int digitParity(int n) {
		// IMPORTANT: your solution *must* be recursive.
		
		throw new UnsupportedOperationException("TODO - implement");
	}
}
