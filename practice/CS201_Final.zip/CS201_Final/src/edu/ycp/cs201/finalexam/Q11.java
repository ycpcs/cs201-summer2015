package edu.ycp.cs201.finalexam;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class Q11 {
	/**
	 * [15 points]
	 * Given a frequency map---a map where the keys are strings,
	 * and the value associated with a key represents the number
	 * of occurrences of the key---return a list that contains
	 * the precise number of occurrences of each key (string)
	 * as indicated by the frequency map.
	 * 
	 * <p>For example, if the frequency map associates "apples" with 2,
	 * and "oranges" with 3, and contains no other keys, then the
	 * method should return a list with 5 elements, 2 of which are
	 * occurrences of "apples", and 3 of which are occurrences of "oranges".
	 * 
	 * <p>The strings in the returned list do not need to be
	 * in any particular order.
	 * 
	 * <p>The method does <em>not</em> need to be recursive, and
	 * your task will be easier if you don't use recursion.
	 * 
	 * <p>See Q11Test for examples of how this method should work.
	 * 
	 * <p>Hint: calling the keySet() method on the map is helpful for
	 * finding out what keys the map has.
	 * 
	 * @param freq a map of string values to their occurrence counts
	 * @return a list containing the specified number of occurrences
	 *         of each string, in any order
	 */
	public static List<String> frequencyMapToList(Map<String, Integer> freq) {
		// Suggestion: add the strings to this array and return it
		ArrayList<String> result = new ArrayList<String>();

		throw new UnsupportedOperationException("TODO - implement");
	}
}
