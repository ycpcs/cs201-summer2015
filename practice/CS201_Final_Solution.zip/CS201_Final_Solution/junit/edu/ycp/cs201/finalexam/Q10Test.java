package edu.ycp.cs201.finalexam;

import static org.junit.Assert.*;

import org.junit.Test;

public class Q10Test {
	@Test
	public void test436() throws Exception {
		assertEquals(1, Q10.digitParity(436));
	}
	
	@Test
	public void test792() throws Exception {
		assertEquals(0, Q10.digitParity(792));
	}
	
	@Test
	public void test787() throws Exception {
		assertEquals(0, Q10.digitParity(787));
	}
	
	@Test
	public void test482() throws Exception {
		assertEquals(0, Q10.digitParity(482));
	}
	
	@Test
	public void test555() throws Exception {
		assertEquals(1, Q10.digitParity(555));
	}
	
	@Test
	public void test90125() throws Exception {
		assertEquals(1, Q10.digitParity(90125));
	}
	
	@Test
	public void test0() throws Exception {
		assertEquals(0, Q10.digitParity(0));
	}
}
