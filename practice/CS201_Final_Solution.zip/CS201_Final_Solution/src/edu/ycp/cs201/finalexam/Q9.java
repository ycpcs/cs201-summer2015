package edu.ycp.cs201.finalexam;

public class Q9 {
	/**
	 * [15 points]
	 * Use recursion to surround each occurrence of the string w
	 * in the string s with single-quote (') characters.
	 * 
	 * <p><b>Requirement</b>: Your implementation <em>must</em> be recursive.
	 * Do <em>not</em> use a loop.  Do <em>not</em> use static field(s).
	 * 
	 * <p>Examples:
	 * <ul>
	 * <li> Q9.beIronic("Java is fun", "Java") should yield "'Java' is fun"
	 * <li> Q9.beIronic("Java is fun", "fun") should yield "Java is 'fun'"
	 * <li> Q9.beIronic("Java is fun", "bacon") should yield "Java is fun"
	 * <li> Q9.beIronic("", "plesiosaur") should yield ""
	 * </ul>
	 * 
	 * <p>Hints:
	 * <ul>
	 * <li> The recursion should be on s
	 * <li> A base case occurs when s is the empty string
	 * <li> Use s.startsWith(w) to see if s starts with w: if it does,
	 *      then surround w with quotes and continue recursively,
	 *      if it doesn't then use the first character of s as-is and
	 *      continue recursively
	 * <li> The recursive call must solve a subproblem that is smaller
	 *      than the original problem
	 * <li> Use string concatenation to extend the solution to the subproblem
	 *      so that it is a solution to the overall problem
	 * </ul>
	 * 
	 * @param s a string
	 * @param word a word, which may or may not occur in s
	 * @return a string in which each occurrence of w in s is surrounded by single quotes
	 */
	public static String beIronic(String s, String word) {
		if (s.equals("")) {
			return "";
		}
		if (s.startsWith(word)) {
			return "'" + word + "'" + beIronic(s.substring(word.length()), word);
		} else {
			return s.charAt(0) + beIronic(s.substring(1), word);
		}
	}
}
